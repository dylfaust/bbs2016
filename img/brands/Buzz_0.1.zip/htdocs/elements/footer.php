<footer>
	<div class="container">
		<p class="small copyright">&copy 2016 Buzzbizz Studios</p>
	</div>
</footer>
