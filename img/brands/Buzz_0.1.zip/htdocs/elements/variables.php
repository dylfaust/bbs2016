<?php

$GLOBALS['site_name'] = 'Buzzbizz Studios Alaska';

//Social Media
$GLOBALS['facebook'] = 'https://www.facebook.com';
$GLOBALS['gplus'] = 'https://www.google.com';
$GLOBALS['pinterest'] = 'https://www.pinterest.com';
$GLOBALS['twitter'] = 'https://www.twitter.com';

//Contact
$GLOBALS['address'] = '3300 C St. #200';
$GLOBALS['location'] = 'Anchorage, AK 99503';
$GLOBALS['phone'] = '907.272.2899';
$GLOBALS['email'] = 'web@bbsalaska.com';

//Vendor
$GLOBALS['signature'] = 'Buzzbizz Studios';
$GLOBALS['signatureLink'] = 'http://buzzbizz.biz';

//Links
$GLOBALS['link_home'] = '/';
$GLOBALS['link_web'] = '/web/';
