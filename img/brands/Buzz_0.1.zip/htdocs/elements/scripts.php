<script src="/js/jquery-2.2.0.min.js"></script> <!-- Jquery -->

<script src="/js/jquery.nicescroll.min.js"></script> <!-- Custom scroll bars -->
<link rel="stylesheet" href="/css/nicescroll.css">

<script src="/js/jquery.stellar.js"></script> <!-- Parallax -->

<script src="/js/mediaelement-and-player.min.js"></script> <!-- Video Player -->
<link rel="stylesheet" href="/css/mediaelementplayer.css">

<script src="/js/jquery.cycle2.js"></script> <!-- Cycle2 Slideshow -->

<script src="/js/main.js"></script> <!-- Custom JS -->

<script src="/js/bootstrap/util.js"></script> <!--bootstrap js -->
<script src="/js/bootstrap/modal.js"></script>
