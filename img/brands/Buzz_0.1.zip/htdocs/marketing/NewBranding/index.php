<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Three Keys to Successful Branding Campaigns
					</h1>
					<hr>
				</div>
			</div>
		</div>
		<div class="container web-directions">
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step1 steps">
					</div>
					<div class="gradient1 step">
						<h1>The Look:</h1>
						<p>Every piece of collateral you put into circulation acts as an ambassador of your brand. From the colors you use to the fonts your pick, every detail must come together in a congruent and pointed manner to ensure everyone who comes into contact with your message feels exactly how you want them about your business.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit rightContainer">
				<div class="stepsContainer right modded1">
					<div class="step2 steps">
						<h1></h1>
					</div>
					<div class="gradient1 step">
						<h1>The Message:</h1>
						<p>Finding the right words are as important to your brand as the look. Crafting your message can be tricky, but with the right help, your message can propel your brand to new heights. Once you find the right words, it’s important to keep continuity while keeping an open mind in letting it grow and transform over time with the interests of your clients.

						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step3 steps">
					</div>
					<div class="gradient1 step">
						<h1>The Audience:</h1>
						<p>The key to a successful branding campaign is to make sure you are talking to the target demographic that will react to your message. Talking to the wrong audience doesn’t do much for your brand but waste time and money. Our expertise is keeping your message in front of people who will most likely respond to your brand.
						</p>
					</div>
				</div>
			</div>
		

		<h1>Unlocking Branding Success</h1>
						<p>Once you have all the keys to branding success, you are ready to launch your branding campaign. The process starts with a marketing strategy, then depending on your strategy, you will need a medi buy plan, an Internet advertising campaign, a digital marketing campign, or all of the above. At Buzzbizz Studios we can take care of every step. Call today to see where we can take your brand.
						</p>
		</div>
		<div class="off-the-grid">
			<h1>Brands We've Worked With</h1>
			<div class="existence">
				<div class="matrix" id="theMatrix">
					<div class="item active">
						<div class="item-control active">
							<div class="item-control-body">
								<!--<h4>Sportsman's Warehouse</h4>-->
								<img src="/img/brands/aclu.png" width="206" height="81" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aclu-of-anchorage/mobile.jpg" width="385" height="2565" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aclu-of-anchorage/tablet.jpg" width="752" height="1829" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/aclu-of-anchorage/live.jpg" width="2445" height="1258" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>TGI Fridays</h4>-->
								<img src="/img/brands/alborn.png" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/mobile.jpg" width="385" height="1859" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/alborn-construction/live.jpg" width="2444" height="1271" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<img src="/img/brands/ams.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/ams-couriers/mobile.jpg" width="385" height="3251" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/ams-couriers/tablet.jpg" width="752" height="2618" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/ams-couriers/live.jpg" width="1920" height="2587" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Denny's Diners</h4>-->
								<img src="/img/brands/arcticlight.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/mobile.jpg" width="385" height="1321" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/arctic-light/live.jpg" width="2445" height="4896" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Renewal By Anderson</h4>-->
								<img src="/img/brands/aurorafineart.png" alt="">
							</div>
						</div>
						<div class="item-body custom6">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/mobile.jpg" width="385" height="2162" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/tablet.jpg" width="752" height="1705" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/aurora-fine-art/live.jpg" width="2446" height="1962" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>GCI Communication</h4>-->
								<img src="/img/brands/autolaundry.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/mobile.jpg" width="385" height="4727" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/tablet.jpg" width="752" height="2765" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/autolaundry/live.jpg" width="2445" height="1769" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Bright Beginnings</h4>-->
								<img src="/img/brands/beanscafe.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/mobile.jpg" width="385" height="3323" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/tablet.jpg" width="752" height="3258" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/beans-cafe/live.jpg" width="2445" height="3595" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Pairmore & Young</h4>-->
								<img src="/img/brands/brightbeginnings.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/mobile.jpg" width="385" height="3877" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/tablet.jpg" width="752" height="2392" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/bright-beginnings/live.jpg" width="2446" height="1890" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>AIH</h4>-->
								<img src="/img/brands/burnettcompanyrealty.png" alt="">
							</div>
						</div>
						<div class="item-body custom2">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/burnett-company-realty/mobile.jpg" width="385" height="1665" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/burnett-company-realty/tablet.jpg" width="752" height="1264" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/burnett-company-realty/live.jpg" width="2445" height="1259" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Chaz Limited</h4>-->
								<img src="/img/brands/chaz.png" alt="">
							</div>
						</div>
						<div class="item-body custom1">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/chaz-limited/mobile.jpg" width="385" height="4103" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/chaz-limited/tablet.jpg" width="752" height="4470" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/chaz-limited/live.jpg" width="2446" height="3179" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Eagle River GDM</h4>-->
								<img src="/img/brands/gdm.png" alt="">
							</div>
						</div>
						<div class="item-body custom2">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/good-deal-magazine/mobile.jpg" width="385" height="2854" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/good-deal-magazine/tablet.jpg" width="752" height="2021" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/good-deal-magazine/live.jpg" width="2445" height="1317" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>New City Entertainment</h4>-->
								<img src="/img/brands/newcity.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/new-city-entertainment/mobile.jpg" width="385" height="5523" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/new-city-entertainment/tablet.jpg" width="752" height="4737" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/new-city-entertainment/live.jpg" width="2446" height="3785" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>One of a Kind Design</h4>-->
								<img src="/img/brands/oneofakinddesign.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/one-of-a-kind-design/mobile.jpg" width="385" height="2533" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/one-of-a-kind-design/tablet.jpg" width="752" height="2542" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/one-of-a-kind-design/live.jpg" width="2445" height="2503" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Party Craft!</h4>-->
								<img src="/img/brands/partycraft.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/party-craft/mobile.jpg" width="385" height="3356" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/party-craft/tablet.jpg" width="752" height="2105" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/party-craft/live.jpg" width="2446" height="2242" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Phillips Cruises</h4>-->
								<img src="/img/brands/phillipscruises.png" alt="">
							</div>
						</div>
						<div class="item-body custom6">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/phillips-cruises/mobile.jpg" width="385" height=7704" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/phillips-cruises/tablet.jpg" width="752" height="6587" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/phillips-cruises/live.jpg" width="2445" height="3025" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Think Office</h4>-->
								<img src="/img/brands/thinkoffice.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/think-office/mobile.jpg" width="385" height="1321" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/think-office/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/think-office/live.jpg" width="2446" height="1195" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Trailboss Solutions</h4>-->
								<img src="/img/brands/trailboss.png" alt="">
							</div>
						</div>
						<div class="item-body custom1">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/trailboss/mobile.jpg" width="385" height="3326" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/trailboss/tablet.jpg" width="752" height="2117" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/trailboss/live.jpg" width="2446" height="1641" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>UnWined</h4>-->
								<img src="/img/brands/unwined.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/unwined/mobile.jpg" width="385" height="3566" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/unwined/tablet.jpg" width="752" height="3454" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/unwined/live.jpg" width="2446" height="2851" alt="">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
