<!DOCTYPE html>
<html lang="en">
	<head>
	<link href="/css/dylStyle.css" rel="stylesheet" />  
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Creating a Media Buy Plan
					</h1>
					<p>
					Buzzbizz Studios offers a unique blend of science, awareness, and gut when creating result-oriented media buying strategies for your company. It’s important to start with the study of microeconomics, couple it with a firm grasp of socioeconomics, and demographic segmentation. Then we pair what the science tells us with an awareness of our community. Top it all off with a touch of gut and you end up with intuitive buying strategies as unique as the companies they are engineered for.
					</p>
					<hr>
				</div>
			</div>
		</div>
		<div class="buyingproc">
			<p class ="buyingprocess">Insert graphic here</p>
		</div>
		
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
