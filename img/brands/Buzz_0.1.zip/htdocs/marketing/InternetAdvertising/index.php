<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Advertising Campaigns
					</h1>
					<p>
					Choosing effective websites to advertise on can be as complicated as deciding how to display your message once have chosen sites. Buzzbizz Studios can help you choose the right sites, how to effectively display your campaign on those sites, and produce the creative to be displayed. We have a monetizing your investment down to the hour. Call the studio today to unlock the possibilities of the Internet. system in placing Internet advertising: plan, buy, probe, and tweak. The advantage you have with Internet advertising is that everything is traceable; you can monetize your investment down to the dollar. Call the studio today to unlock the possibilities of the Internet.
					</p>
					<hr>
				</div>
			</div>
		
		</div>

		<div class="container web-directions">
		<h1 id = "internet-advertising">Five Steps to Successful Internet Advertising</h1>
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step1 steps">
						<h1>01</h1>
					</div>
					<div class="gradient1 step">
						<h1>LOCATE</h1>
						<p>There are a lot of websites you can advertise on, but few are the right fit. Each company will find different results from each site available. The first priority is to find the perfect fit for your product and target audience.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit rightContainer">
				<div class="stepsContainer right modded1">
					<div class="step2 steps">
						<h1>02</h1>
					</div>
					<div class="gradient1 step">
						<h1>NEGOTIATE</h1>
						<p>Many websites with advertising opportunities are run independently. Others are part of Internet advertising networks and extended reach programs. Both scenarios present options for negotiation.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step3 steps">
						<h1>03</h1>
					</div>
					<div class="gradient1 step">
						<h1>MESSAGE</h1>
						<p>There are two main objectives to Internet advertising: brand awareness or call to action. It is imperative to create the right message with eye-catching creative to influence website visitors to take the action you want.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit rightContainer">
				<div class="stepsContainer right">
					<div class="step4 steps">
						<h1>04</h1>
					</div>
					<div class="gradient1 step">
						<h1>MEASURE</h1>
						<p>Once the campaign is running, it is time to measure results. This can happen immediately, like the first day. Data is at our fingertips and we don’t have to wait as long as conventional media to start getting useful info.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step5 steps">
						<h1>05</h1>
					</div>
					<div class="gradient1 step">
						<h1>TWEAK</h1>
						<p>Taking what we learn from the data, we start making adjustments as needed. Sometime we may create parallel campaigns on the same site in order to see if one idea works better than another. A/B testing can be a game changer.
						</p>
					</div>
				</div>
			</div>
		</div>
	
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
