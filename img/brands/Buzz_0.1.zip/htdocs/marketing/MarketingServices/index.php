<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Your marketing fiduciary
					</h1>
					<p>
					Buzzbizz Studios’ marketing services are best suited for small to medium sized businesses and non-profit organizations. Regardless of your size or budget, we take it upon ourselves to become your marketing fiduciary – always and truly working in your best marketing interests. We take the honor of helping you with your success very seriously. We believe your success is our success and in achieving that success we will always act in your best interest. This means our interests can never be a part of your marketing plan. We promise to sacrifice your needs to advance any of our own.
					<br><br>
					What this all means is that your marketing campaign isn’t treated as a stepping-stone to the next big account or fodder for our awards shelf. It means we keep your marketing on time, on target, on budget, and are always working on making it better. So if you have heard the horror stories of the large agency experience or are coming out of a bad experience yourself, please come see the Buzzbizz Studios difference. We always start with a complimentary no obligation consultation to get a taste for our marketing flavor and be sure that we are the right fit for your situation.
					</p>
					<hr>
				</div>
			</div>
		</div>
		
		<div class="off-the-grid">
			<h1>Brands We've Worked With</h1>
			<div class="existence">
				<div class="matrix" id="theMatrix">
					<div class="item active">
						<div class="item-control active">
							<div class="item-control-body">
								<!--<h4>Sportsman's Warehouse</h4>-->
								<img src="/img/brands/aclu.png" width="206" height="81" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aclu-of-anchorage/mobile.jpg" width="385" height="2565" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aclu-of-anchorage/tablet.jpg" width="752" height="1829" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/aclu-of-anchorage/live.jpg" width="2445" height="1258" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>TGI Fridays</h4>-->
								<img src="/img/brands/alborn.png" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/mobile.jpg" width="385" height="1859" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/alborn-construction/live.jpg" width="2444" height="1271" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Denny's Diner</h4>-->
								<img src="/img/brands/arcticlight.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/mobile.jpg" width="385" height="1321" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/arctic-light/live.jpg" width="2445" height="4896" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Renewal By Anderson</h4>-->
								<img src="/img/brands/aurorafineart.png" alt="">
							</div>
						</div>
						<div class="item-body custom6">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/mobile.jpg" width="385" height="2162" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/tablet.jpg" width="752" height="1705" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/aurora-fine-art/live.jpg" width="2446" height="1962" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>GCI Communication</h4>-->
								<img src="/img/brands/autolaundry.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/mobile.jpg" width="385" height="4727" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/tablet.jpg" width="752" height="2765" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/autolaundry/live.jpg" width="2445" height="1769" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Bright Beginnings</h4>-->
								<img src="/img/brands/beanscafe.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/mobile.jpg" width="385" height="3323" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/tablet.jpg" width="752" height="3258" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/beans-cafe/live.jpg" width="2445" height="3595" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Pairmore & Young</h4>-->
								<img src="/img/brands/brightbeginnings.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/mobile.jpg" width="385" height="3877" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/tablet.jpg" width="752" height="2392" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/bright-beginnings/live.jpg" width="2446" height="1890" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>AIH</h4>-->
								<img src="/img/brands/burnettcompanyrealty.png" alt="">
							</div>
						</div>
						<div class="item-body custom2">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/burnett-company-realty/mobile.jpg" width="385" height="1665" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/burnett-company-realty/tablet.jpg" width="752" height="1264" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/burnett-company-realty/live.jpg" width="2445" height="1259" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Oreck Vacuums</h4>-->
								<img src="/img/brands/chaz.png" alt="">
							</div>
						</div>
						<div class="item-body custom1">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/chaz-limited/mobile.jpg" width="385" height="4103" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/chaz-limited/tablet.jpg" width="752" height="4470" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/chaz-limited/live.jpg" width="2446" height="3179" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Bristol Bay Native Corp</h4>-->
								<img src="/img/brands/gdm.png" alt="">
							</div>
						</div>
						<div class="item-body custom2">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/good-deal-magazine/mobile.jpg" width="385" height="2854" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/good-deal-magazine/tablet.jpg" width="752" height="2021" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/good-deal-magazine/live.jpg" width="2445" height="1317" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Ohana Media Group</h4>-->
								<img src="/img/brands/newcity.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/new-city-entertainment/mobile.jpg" width="385" height="5523" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/new-city-entertainment/tablet.jpg" width="752" height="4737" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/new-city-entertainment/live.jpg" width="2446" height="3785" alt="">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
