<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Marketing Strategy Process
					</h1>
					<p>
					Every good marketing plan comes with great strategy. There is a process to coming up with successful marketing strategies. We have a seven-step process to help you get where you want to go with your marketing.
					</p>
					<p>
					Graphic goes here
					</p>

					<br>
					<h1>
						Strategy-On-The-Go
					</h1>
					<p>
					The hard work doesn’t stop once you have deployed your awesome marketing strategy. Rather, this is where the hard work begins. Marketing strategies need to be treated like business plans in that they are always evolving. Once launched, your marketing campaign needs to be under constant scrutiny and measured every way it can to ensure what you thought worked yesterday is still effective today. This is why we enlist Strategy-On-The-Go. It makes sure your marketing strategy and message never grow stale or become inefective. We constantly massage what works and tweak or illiminating what doesn’t.
					</p>

					<br>
					<h1>
						Levels of Engagement
					</h1>
					<p>
					Buzzbizz Studios can be as much or as little part of your strategy process as you wish. We have three levels of engagement we offer to ensure each client is getting exactly whay they need out of their marketing.
					</p>
					<hr>
				</div>
			</div>
		</div>
		<div class="container web-directions">
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step1 steps">
						<h1>01</h1>
					</div>
					<div class="gradient1 step">
						<h1>CONSULTING</h1>
						<p>Many of our best clients are those with marketing degrees, successful businesses, or are just die-hard Do-It-Yourselfers. These clients are looking for a solid and professional sounding board and our level-one e
engagement is a perfect fit.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit rightContainer">
				<div class="stepsContainer right modded1">
					<div class="step2 steps">
						<h1>02</h1>
					</div>
					<div class="gradient1 step">
						<h1>STRATEGY</h1>
						<p>Level-two engagement allows us to work together with our clients in conceiving and producing new marketing campaigns. Great for engaged owners and directors too busy to do the back end tasks but can handle frontline implementation.
						</p>
					</div>
				</div>
			</div>
			<div class="apieceofit leftContainer">
				<div class="stepsContainer left">
					<div class="step3 steps">
						<h1>03</h1>
					</div>
					<div class="gradient1 step">
						<h1>DONE-FOR-YOU</h1>
						<p>Successful business owners and busy marketing directors love our level-three engagement because things are literally done with very little effort on the client’s part. This is perfect if you don’t have time to manage your own marketing.
						</p>
					</div>
				</div>
			</div>
		</div>
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
