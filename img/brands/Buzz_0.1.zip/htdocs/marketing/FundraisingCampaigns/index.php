<!DOCTYPE html>
<html lang="en">
	<head>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/elements/fullhead.php'); ?>
		<title>Web Development ::  <?php echo $GLOBALS['site_name'];?></title>
		<meta name="description" content="Buzzbizz Marketing">
	</head>
	<body class="main secondary web">
		<header id="header">
			<?php include 'nav.php' ?>
		</header>
		<main>
		<div class="top-section" id="top-section">
			<?php include 'web/intro.php'; ?>
			<nav class="secondary with-needs landing" id="secondaryNav">
				<div class="container">
					<?php include 'web/nav.php'; ?>
				</div>
			</nav>
		</div>
		<div class="container text-align-center intro">
			<div class="row">
				<div class="col-xs-12">
					<h1>
						Fundraising Campaigns
					</h1>
					<p>
					Fundraising campaigns can be tricky because many times, funds are extremely tight and media outlets are swamped with request for free airtime everyday. This is where Buzzbizz Studios’ creative buying strategies mixed with carefully planned gorilla marketing tactics can become force multipliers for your cause. It is our job to help you find the best way to leverage your volunteer and limited currency resources. With a mix of good will from the media and public, creative marketing strategies, and heart tugging messaging we find ways to help you reach your fundraising goals.
					</p>
					<hr>
				</div>
			</div>
		</div>
		
		</div>
		<div class="off-the-grid">
			<h1>Brands We've Worked With</h1>
			<div class="existence">
				<div class="matrix" id="theMatrix">
					<div class="item active">
						<div class="item-control active">
							<div class="item-control-body">
								<!--<h4>Sportsmans Warehouse</h4>-->
								<img src="/img/brands/sportsmans.jpg" width="206" height="81" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/sportsmans.jpg" width="385" height="2565" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/sportsmans.jpg" width="752" height="1829" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/sportsmans.jpg" width="2445" height="1258" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Alborn Construction</h4>-->
								<img src="/img/brands/alborn.png" alt="">
							</div>
						</div>
						<div class="item-body">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/mobile.jpg" width="385" height="1859" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/alborn-construction/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/alborn-construction/live.jpg" width="2444" height="1271" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<img src="/img/brands/ams.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/ams-couriers/mobile.jpg" width="385" height="3251" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/ams-couriers/tablet.jpg" width="752" height="2618" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/ams-couriers/live.jpg" width="1920" height="2587" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Arctic Light Gallery & Excursions</h4>-->
								<img src="/img/brands/arcticlight.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/mobile.jpg" width="385" height="1321" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/arctic-light/tablet.jpg" width="752" height="1330" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/arctic-light/live.jpg" width="2445" height="4896" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Aurora Fine Art</h4>-->
								<img src="/img/brands/aurorafineart.png" alt="">
							</div>
						</div>
						<div class="item-body custom6">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/mobile.jpg" width="385" height="2162" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/aurora-fine-art/tablet.jpg" width="752" height="1705" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/aurora-fine-art/live.jpg" width="2446" height="1962" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Automated Laundry</h4>-->
								<img src="/img/brands/autolaundry.png" alt="">
							</div>
						</div>
						<div class="item-body custom5">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/mobile.jpg" width="385" height="4727" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/autolaundry/tablet.jpg" width="752" height="2765" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/autolaundry/live.jpg" width="2445" height="1769" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Bean's Cafe</h4>-->
								<img src="/img/brands/beanscafe.png" alt="">
							</div>
						</div>
						<div class="item-body custom4">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/mobile.jpg" width="385" height="3323" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/beans-cafe/tablet.jpg" width="752" height="3258" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/beans-cafe/live.jpg" width="2445" height="3595" alt="">
								</div>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="item-control">
							<div class="item-control-body">
								<!--<h4>Bright Beginnings</h4>-->
								<img src="/img/brands/brightbeginnings.png" alt="">
							</div>
						</div>
						<div class="item-body custom3">
							<div class="layout">
								<div class="phoneShine">
									<img class="shine" src="/img/phone_shine.png" width="197" height="379" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/mobile.jpg" width="385" height="3877" alt="">
									</div>
									<img class="phone" src="/img/phone.png" width="197" height="379" alt="">
								</div>
								<div class="tabletShine">
									<img class="shine" src="/img/tablet_shine.png" width="472" height="631" alt="">
									<div class="viewport">
										<img src="/img/brands/web/bright-beginnings/tablet.jpg" width="752" height="2392" alt="">
									</div>
									<img class="tablet" src="/img/tablet.png" width="472" height="631" alt="">
								</div>
								<div class="full scroller">
									<img class="full" src="/img/brands/web/bright-beginnings/live.jpg" width="2446" height="1890" alt="">
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="ribbon orange">
			<div class="container">
				<h1>
					Ready to take your story to the World Wide Web?
				</h1>
				<a class="btn btn-block" href="#">Let's Talk</a>
			</div>
		</div>
		</main>
		<?php include 'video-background.php'; ?>
		<?php include 'footer.php'; ?>
	</body>
	<script>
		function start() {
			main();
			secondaryMain();
			parallax();
			storeMatrix();
		}
	</script>
	<?php include 'scripts.php'; ?>
	<script>
		window.onscroll = secondaryScroll;
		$(".nav-web").addClass("active");
	</script>
	<script src="/js/matrix.js"></script>
</html>
